﻿using ExpenseTracker.BusinessLogic.Common;
using ExpenseTracker.BusinessLogic.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using ExpenseTracker.API.Controllers;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class BillsController : BaseController
{
    private readonly IBillService _billService;

    public BillsController(IBillService billService)
    {
        _billService = billService;
    }
    

    [HttpPost]
    public async Task<IActionResult> CreateBill(
        [FromBody] BillCreateDto dto)
    {
        dto.UserId = UserId; 
        var result = await _billService.CreateBillAsync(dto);

        return Ok(ApiResponse<BillResponseDto>
            .SuccessResponse(result, "Bill created"));
    }

    [HttpGet]
    public async Task<IActionResult> GetBills()
    {
        var bills = await _billService.GetUserBillsAsync(UserId);

        return Ok(ApiResponse<List<BillCreateDto>>
            .SuccessResponse(bills));
    }

    [HttpDelete("{billId}")]
    public async Task<IActionResult> DeleteBill(
        int billId)
    {

        var success = await _billService.DeleteBillAsync(billId, UserId);

        if (!success)
            return NotFound(ApiResponse<string>
                .FailureResponse( "Bill not found" ));

        return Ok(ApiResponse<string>
            .SuccessResponse("Bill deleted"));
    }
}
﻿using AutoMapper;
using ExpenseTracker.API.Security;
using ExpenseTracker.Infrastructure.Entities;

namespace ExpenseTracker.BusinessLogic.Mappings;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Bill mappings
        CreateMap<BillCreateDto, Bill>();
        CreateMap<Bill, BillResponseDto>();
        CreateMap<Bill, BillCreateDto>();

        // User mappings
        CreateMap<User, LoginResponseDto>();
        CreateMap<User, UserProfileResponseDTO>();
        CreateMap<RegisterUserRequestDTO, User>()
            .ForMember(dest => dest.PasswordHash,
                opt => opt.MapFrom(src => PasswordHasher.Hash(src.Password)));
        // Add more mappings here as project grows
    }
}